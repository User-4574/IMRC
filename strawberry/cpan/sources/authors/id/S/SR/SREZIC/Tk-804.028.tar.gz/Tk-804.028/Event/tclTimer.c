#define TCL_EVENT_IMPLEMENT
#include "../pTk/tclTimer.c"
